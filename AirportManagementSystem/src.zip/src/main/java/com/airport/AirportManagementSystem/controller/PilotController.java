package com.airport.AirportManagementSystem.controller;

public class PilotController {

}
